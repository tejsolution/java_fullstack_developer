package com.project.web.Reposity;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.web.Model.Student;

public interface StudentInfo extends JpaRepository<Student, Integer> {
	public Student findByemail(String email);
}



