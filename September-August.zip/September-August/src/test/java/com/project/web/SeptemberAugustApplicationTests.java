package com.project.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeptemberAugustApplicationTests {

	@Test
	void contextLoads() {
	}

}
